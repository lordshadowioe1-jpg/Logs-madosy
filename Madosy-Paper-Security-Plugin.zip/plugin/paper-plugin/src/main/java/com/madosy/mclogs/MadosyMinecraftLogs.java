package com.madosy.mclogs;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MadosyMinecraftLogs extends JavaPlugin implements Listener {
    private HttpClient http;
    private ExecutorService executor;
    private String endpoint, guildId, secret;
    private int timeout;
    private MadosySecurityListener securityListener;

    @Override public void onEnable() {
        saveDefaultConfig();
        endpoint = getConfig().getString("bot-url", "").replaceAll("/+$", "") + "/api/minecraft/logs";
        guildId = getConfig().getString("guild-id", "");
        secret = getConfig().getString("secret", "");
        timeout = Math.max(2, getConfig().getInt("http-timeout-seconds", 5));
        executor = Executors.newFixedThreadPool(2, r -> { Thread t = new Thread(r, "Madosy-Logs-HTTP"); t.setDaemon(true); return t; });
        http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(timeout)).build();
        if (endpoint.startsWith("/api") || guildId.isBlank() || secret.isBlank() || secret.startsWith("CHANGE_")) {
            getLogger().severe("راجع bot-url و guild-id و secret في config.yml");
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        securityListener = new MadosySecurityListener(this);
        getLogger().info("Madosy Minecraft Logs + Security enabled.");
    }

    @Override public void onDisable() { if (securityListener != null) securityListener.shutdown(); if (executor != null) executor.shutdown(); }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }
    boolean isBedrock(UUID uuid) { return "Bedrock".equals(playerType(uuid)); }
    private String playerType(UUID uuid) {
        if (Bukkit.getPluginManager().isPluginEnabled("floodgate")) {
            try {
                Class<?> api = Class.forName("org.geysermc.floodgate.api.FloodgateApi");
                Object instance = api.getMethod("getInstance").invoke(null);
                Object result = api.getMethod("isFloodgatePlayer", UUID.class).invoke(instance, uuid);
                if (Boolean.TRUE.equals(result)) return "Bedrock";
            } catch (Throwable ignored) { }
        }
        return "Java";
    }
    private String coords(Location l) { return l.getWorld().getName() + " " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ(); }
    void sendSecurity(String type, String player, String details, String severity) {
        String json = "{\"guildId\":\"" + esc(guildId) + "\",\"type\":\"" + esc(type) + "\",\"player\":\"" + esc(player) + "\",\"details\":\"" + esc(details) + "\",\"severity\":\"" + esc(severity) + "\"}";
        executor.submit(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder(URI.create(endpoint.replace("/api/minecraft/logs", "/api/minecraft/security"))).timeout(Duration.ofSeconds(timeout))
                    .header("Content-Type", "application/json; charset=utf-8").header("X-Madosy-Secret", secret)
                    .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8)).build();
                HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
                if (res.statusCode() >= 400) getLogger().warning("Security API returned HTTP " + res.statusCode());
            } catch (Exception e) { getLogger().warning("Could not send security alert: " + e.getMessage()); }
        });
    }
    private void send(String event, String player, UUID uuid, String details) {
        String type = uuid == null ? "Server" : playerType(uuid);
        String json = "{\"guildId\":\"" + esc(guildId) + "\",\"event\":\"" + esc(event) + "\",\"player\":\"" + esc(player) + "\",\"playerType\":\"" + type + "\",\"details\":\"" + esc(details) + "\"}";
        executor.submit(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder(URI.create(endpoint)).timeout(Duration.ofSeconds(timeout))
                    .header("Content-Type", "application/json; charset=utf-8").header("X-Madosy-Secret", secret)
                    .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8)).build();
                HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
                if (res.statusCode() >= 400) getLogger().warning("Bot returned HTTP " + res.statusCode());
            } catch (Exception e) { getLogger().warning("Could not send log to Madosy bot: " + e.getMessage()); }
        });
    }
    @EventHandler public void join(PlayerJoinEvent e) { send("دخول لاعب", e.getPlayer().getName(), e.getPlayer().getUniqueId(), "انضم إلى السيرفر"); }
    @EventHandler public void quit(PlayerQuitEvent e) { send("خروج لاعب", e.getPlayer().getName(), e.getPlayer().getUniqueId(), "غادر السيرفر"); }
    @EventHandler public void chat(AsyncPlayerChatEvent e) { send("رسالة شات", e.getPlayer().getName(), e.getPlayer().getUniqueId(), e.getMessage()); }
    @EventHandler public void breakBlock(BlockBreakEvent e) { Block b=e.getBlock(); send("كسر بلوك", e.getPlayer().getName(), e.getPlayer().getUniqueId(), b.getType()+" عند "+coords(b.getLocation())); }
    @EventHandler public void placeBlock(BlockPlaceEvent e) { Block b=e.getBlockPlaced(); send("وضع بلوك", e.getPlayer().getName(), e.getPlayer().getUniqueId(), b.getType()+" عند "+coords(b.getLocation())); }
    @EventHandler public void death(PlayerDeathEvent e) { Player p=e.getEntity(); String killer=p.getKiller()==null?"غير معروف":p.getKiller().getName(); send("موت لاعب", p.getName(), p.getUniqueId(), e.getDeathMessage()+" | القاتل: "+killer); }
    @EventHandler public void command(PlayerCommandPreprocessEvent e) {
        String cmd=e.getMessage().split(" ", 2)[0].toLowerCase();
        if (cmd.startsWith("/op") || cmd.startsWith("/deop") || cmd.startsWith("/ban") || cmd.startsWith("/kick") || cmd.startsWith("/gamemode") || cmd.startsWith("/give"))
            send("أمر إداري", e.getPlayer().getName(), e.getPlayer().getUniqueId(), e.getMessage());
    }
    @EventHandler public void explode(EntityExplodeEvent e) {
        Entity entity=e.getEntity(); String who=entity.getType().name();
        send("انفجار", who, null, "الموقع: "+coords(e.getLocation())+" | البلوكات المتأثرة: "+e.blockList().size());
    }
}
