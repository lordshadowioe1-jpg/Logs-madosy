package com.madosy.mclogs;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class MadosySecurityListener implements Listener {
    private final MadosyMinecraftLogs plugin;
    private final Map<UUID, Deque<Long>> attacks = new ConcurrentHashMap<>();
    private final Map<UUID, Deque<Long>> ores = new ConcurrentHashMap<>();
    private final Map<UUID, Deque<Long>> placements = new ConcurrentHashMap<>();
    private final Map<UUID, Location> positions = new ConcurrentHashMap<>();
    private final Map<String, Long> alertCooldown = new ConcurrentHashMap<>();
    private BukkitTask movementTask;

    public MadosySecurityListener(MadosyMinecraftLogs plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
        movementTask = Bukkit.getScheduler().runTaskTimer(plugin, this::checkMovement, 20L, 20L);
    }

    public void shutdown() { if (movementTask != null) movementTask.cancel(); }
    private long now() { return System.currentTimeMillis(); }
    private boolean enabled(String key) { return plugin.getConfig().getBoolean("security." + key, true); }
    private boolean bedrock(Player p) { return plugin.isBedrock(p.getUniqueId()); }
    private String coords(Location l) { return l.getWorld().getName()+" "+l.getBlockX()+","+l.getBlockY()+","+l.getBlockZ(); }
    private <T> Deque<Long> prune(Map<UUID,Deque<Long>> map, UUID id, long window) {
        Deque<Long> q=map.computeIfAbsent(id,k->new ArrayDeque<>()); long cutoff=now()-window;
        synchronized(q){ while(!q.isEmpty() && q.peekFirst()<cutoff) q.removeFirst(); }
        return q;
    }
    private void alert(String type, Player p, String detail, String severity) {
        String key=type+":"+(p==null?"server":p.getUniqueId().toString()); long t=now();
        Long last=alertCooldown.put(key,t); if(last!=null && t-last<30000) return;
        plugin.sendSecurity(type, p == null ? "Server" : p.getName(), detail, severity);
    }

    private void checkMovement() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            Location current=p.getLocation(); Location previous=positions.put(p.getUniqueId(),current.clone());
            if (previous==null || p.isInsideVehicle() || p.isFlying() || p.getAllowFlight() || p.getGameMode()==GameMode.SPECTATOR) continue;
            if (current.getWorld()!=previous.getWorld()) continue;
            double horizontal=Math.hypot(current.getX()-previous.getX(),current.getZ()-previous.getZ());
            if (enabled("antiSpeed") && horizontal>11.5 && !p.isGliding() && !p.isSwimming())
                alert("Anti-Speed",p,String.format(Locale.US,"تحرك %.1f بلوك خلال ثانية؛ الموقع %s",horizontal,coords(current)),"medium");
            if (enabled("antiFly") && current.getY()-previous.getY()>5.2 && !p.isGliding() && !p.isSwimming() && !p.isOnGround())
                alert("Anti-Fly",p,"ارتفاع عمودي غير معتاد خلال ثانية؛ الموقع "+coords(current),"medium");
        }
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) { positions.put(e.getPlayer().getUniqueId(),e.getPlayer().getLocation().clone()); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { UUID id=e.getPlayer().getUniqueId(); positions.remove(id); attacks.remove(id); ores.remove(id); placements.remove(id); }

    @EventHandler public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (enabled("antiReach") && e.getEntity() instanceof org.bukkit.entity.LivingEntity target) {
            double dist=p.getEyeLocation().distance(target.getLocation().add(0, target.getHeight()/2, 0));
            if (dist>4.35) alert("Anti-Reach",p,String.format(Locale.US,"مدى الضربة %.2f بلوك (الحد التقريبي 4.35)",dist),"high");
        }
        if (enabled("antiAura")) {
            Deque<Long> q=prune(attacks,p.getUniqueId(),1000);
            synchronized(q){ q.addLast(now()); if(q.size()>12) alert("Combat Pattern",p,"عدد ضربات مرتفع جداً: "+q.size()+" خلال ثانية؛ قد يكون بسبب أداة قتال أو تكرار سريع","medium"); }
        }
    }

    @EventHandler public void onBreak(BlockBreakEvent e) {
        if (!enabled("xrayHeuristic")) return;
        String mat=e.getBlock().getType().name();
        if (!(mat.endsWith("_ORE") || mat.equals("ANCIENT_DEBRIS") || mat.equals("RAW_GOLD_BLOCK") || mat.equals("RAW_IRON_BLOCK") || mat.equals("RAW_COPPER_BLOCK"))) return;
        Player p=e.getPlayer(); Deque<Long> q=prune(ores,p.getUniqueId(),120000);
        synchronized(q){ q.addLast(now()); if(q.size()==15) alert("X-Ray Heuristic",p,"تم تعدين 15 خامة خلال دقيقتين. هذه إشارة اشتباه وليست إثبات X-Ray؛ راجع سجل التعدين","medium"); }
    }

    @EventHandler public void onPlace(BlockPlaceEvent e) {
        if (!enabled("antiLag")) return;
        Player p=e.getPlayer(); Deque<Long> q=prune(placements,p.getUniqueId(),5000);
        synchronized(q){ q.addLast(now()); if(q.size()==45) alert("Anti-Lag",p,"وضع 45 بلوك خلال 5 ثوانٍ؛ احتمال بناء آلة لاق أو بناء سريع","medium"); }
    }
    @EventHandler public void onExplode(EntityExplodeEvent e) {
        if (enabled("antiLag") && e.blockList().size()>=80) alert("Anti-Lag",null,"انفجار كبير أثّر على "+e.blockList().size()+" بلوك عند "+coords(e.getLocation()),"high");
    }

    @EventHandler public void onGameMode(PlayerGameModeChangeEvent e) {
        if (enabled("adminAudit") && e.getNewGameMode()==GameMode.CREATIVE)
            alert("Admin Audit",e.getPlayer(),"تغيير نمط اللعب إلى CREATIVE؛ تحقق من سبب التغيير والصلاحية","high");
    }

    @EventHandler public void onPlayerAdminCommand(PlayerCommandPreprocessEvent e) {
        if (!enabled("adminAudit")) return;
        String cmd=e.getMessage().trim().toLowerCase(Locale.ROOT);
        if (cmd.matches("^/(minecraft:)?(op|deop|gamemode|ban|ban-ip|pardon|pardon-ip|kick|give)(\\s|$).*"))
            alert("Admin Audit",e.getPlayer(),"أمر إداري من اللاعب: "+e.getMessage(),"high");
    }

    @EventHandler public void onServerCommand(ServerCommandEvent e) {
        if (!enabled("adminAudit")) return;
        String cmd=e.getCommand().trim().toLowerCase(Locale.ROOT);
        if (cmd.matches("^(minecraft:)?(op|deop|gamemode|ban|ban-ip|pardon|pardon-ip|kick|give|stop|reload)(\\s|$)"))
            alert("Admin Audit",null,"أمر من الكونسول: /"+e.getCommand(),"high");
    }
}
