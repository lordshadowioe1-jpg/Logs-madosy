# Madosy Paper Logs + Security

Paper plugin that sends Minecraft logs and heuristic security alerts to the Madosy Discord bot.

## Requirements
- Paper 1.20.4+ (compiled against Paper API 1.20.4)
- Java 17+
- Existing Madosy Discord bot with the Minecraft Logs + Security page
- Floodgate is optional and used only to label Bedrock players in logs

## Setup
1. Build with `mvn clean package`.
2. Copy `target/madosy-minecraft-logs-1.0.0.jar` into the server `plugins/` folder.
3. Start the server once, then stop it.
4. In `plugins/MadosyMinecraftLogs/config.yml`, set `bot-url`, `guild-id`, and `secret`.
5. In the Madosy dashboard choose a channel in both Minecraft Logs and Minecraft Security. The same secret is shared by both pages.
6. Restart Paper.

## Detection notes
This plugin sends alerts; it does not automatically ban or kick. Movement, reach, combat-rate, mining, and block-placement checks are heuristics and can produce false positives due to latency, effects, server configuration, or legitimate gameplay. X-Ray cannot be reliably proven from block-break events alone.

For stronger X-Ray prevention, also enable Paper's built-in anti-xray in `config/paper-world-defaults.yml` under `anticheat.anti-xray` (choose engine-mode 2 and configure hidden-blocks / replacement-blocks for your world). Review Paper documentation for the exact options supported by your Paper version.

Admin audit watches player commands and gamemode changes plus server console commands. It cannot identify the human operator behind every console command or every third-party permission plugin action. Restrict console/VPS access and use a permission plugin with audit logging.
