# Madosy Minecraft Logs — Paper Plugin

Requires Paper 1.20.4+ and Java 17+. Floodgate is optional and is detected at runtime.

## Setup
1. Build with Maven: `mvn clean package` (the JAR is created in `target/`).
2. Edit `src/main/resources/config.yml` before building, or edit `plugins/MadosyMinecraftLogs/config.yml` after the first server start.
3. Set `bot-url` to the public base URL of your Madosy bot/dashboard (no `/api/...` suffix).
4. Set `guild-id` to the Discord server ID.
5. Set `secret` to exactly the same random secret as `MC_LOG_SECRET` in the bot `.env`.
6. Copy `target/madosy-minecraft-logs-1.0.0.jar` into the Paper server `plugins/` folder and restart.

Events currently logged: join, quit, chat, block break/place, player death, selected player-issued admin commands (op/deop/ban/kick/gamemode/give), and explosions. Floodgate players are labeled Bedrock; other players are labeled Java.

The plugin sends HTTP POST requests to `/api/minecraft/logs` using the `X-Madosy-Secret` header. Configure `MC_LOG_GUILD_ID` and `MC_LOG_CHANNEL_ID` in the bot `.env` to choose the Discord server and log channel. Do not expose the secret publicly.
